<?php


namespace ResqueSerial\Exception;


class ForkException extends \Exception {

}