<?php


namespace ResqueSerial\ReserveStrategy;
interface IReserveStrategy {

    function reserve();

}