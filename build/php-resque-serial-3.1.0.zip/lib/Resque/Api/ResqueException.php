<?php


namespace Resque\Api;

/**
 * All exceptions thrown from resque api will be descendants of this class.
 */
abstract class ResqueException extends \Exception {

}