<?php


namespace Resque\Task;


class ApplicationTaskCreationException extends \Exception {

}