<?php


namespace Resque\Api;


use Resque\Exception;

class FailException extends Exception {
}