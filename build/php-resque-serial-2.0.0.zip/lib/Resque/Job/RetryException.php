<?php


namespace Resque\Job;


use Resque\Exception;

class RetryException extends Exception {

}