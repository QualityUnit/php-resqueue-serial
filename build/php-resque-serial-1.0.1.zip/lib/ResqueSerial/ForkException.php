<?php


namespace ResqueSerial;


class ForkException extends \Exception {

}