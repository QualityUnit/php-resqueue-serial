<?php


namespace ResqueSerial\Task;


class TaskCreationException extends \Exception {

}