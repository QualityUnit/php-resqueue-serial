<?php

namespace Resque\Protocol;

use Resque\ResqueException;

class UniqueLockMissingException extends ResqueException {
}