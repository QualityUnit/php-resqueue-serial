<?php

namespace Resque\Api;

/**
 * Redis related exceptions
 */
class RedisError extends \Error {
}