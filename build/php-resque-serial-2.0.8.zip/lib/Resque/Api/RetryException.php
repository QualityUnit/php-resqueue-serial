<?php


namespace Resque\Api;


use Resque\Exception;

class RetryException extends Exception {

}