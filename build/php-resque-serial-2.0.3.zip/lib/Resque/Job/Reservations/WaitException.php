<?php


namespace Resque\Job\Reservations;


use Resque\Exception;

class WaitException extends Exception {
}