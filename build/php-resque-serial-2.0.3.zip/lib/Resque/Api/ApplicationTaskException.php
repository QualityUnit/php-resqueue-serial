<?php


namespace Resque\Api;


use Resque\Exception;

class ApplicationTaskException extends Exception {

}