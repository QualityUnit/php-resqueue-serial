<?php

namespace Resque\Api;

use Resque\Exception;

/**
 * Redis related exceptions
 */
class RedisException extends Exception {
}