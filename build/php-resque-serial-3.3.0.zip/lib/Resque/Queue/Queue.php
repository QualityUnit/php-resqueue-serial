<?php


namespace Resque\Queue;


use Resque;
use Resque\Api\Job;
use Resque\Api\UniqueException;
use Resque\Job\IJobSource;
use Resque\Job\QueuedJob;
use Resque\Key;
use Resque\Log;
use Resque\ResqueImpl;
use Resque\Stats;
use Resque\Stats\QueueStats;
use Resque\UniqueList;

class Queue implements IJobSource {

    /** @var string */
    private $name;
    /** @var Stats */
    private $stats;

    public function __construct($name) {
        $this->name = $name;
        $this->stats = new QueueStats($name);
    }

    /**
     * @param Job $job
     * @param bool $checkUnique
     *
     * @return QueuedJob
     * @throws UniqueException
     */
    public static function push(Job $job, $checkUnique = true) {
        $queuedJob = new QueuedJob($job, ResqueImpl::getInstance()->generateJobId());

        UniqueList::add($job, !$checkUnique);

        // Push a job to the end of a specific queue. If the queue does not exist, then create it as well.
        Resque::redis()->sAdd(Key::queues(), $job->getQueue());
        Resque::redis()->rPush(Key::queue($job->getQueue()), json_encode($queuedJob->toArray()));

        $queuedJob->reportQueued();

        return $queuedJob;
    }

    /**
     * @return Stats
     */
    public function getStats() {
        return $this->stats;
    }

    /**
     * @inheritdoc
     */
    public function popBlocking($timeout) {
        $payload = Resque::redis()->blPop(Key::queue($this->name), $timeout);
        if (!is_array($payload) || !isset($payload[1])) {
            return null;
        }

        $data = json_decode($payload[1], true);
        if (!is_array($data)) {
            Log::error('Payload data corrupted on dequeue.', ['payload' => $payload[1]]);
            return null;
        }

        Log::debug('Job retrieved from queue.', ['payload' => $payload[1]]);

        $queuedJob = QueuedJob::fromArray($data);
        $this->writeStats($queuedJob);

        return $queuedJob;
    }

    /**
     * @inheritdoc
     */
    public function popNonBlocking() {
        $data = json_decode(Resque::redis()->lPop(Key::queue($this->name)), true);
        if (!is_array($data)) {
            return null;
        }

        $queuedJob = QueuedJob::fromArray($data);
        $this->writeStats($queuedJob);

        return $queuedJob;
    }

    /**
     * @inheritdoc
     */
    public function toString() {
        return $this->name;
    }

    private function writeStats(QueuedJob $queuedJob) {
        $timeQueued = floor((microtime(true) - $queuedJob->getQueuedTime()) * 1000);
        $this->stats->incQueueTime($timeQueued);
        $this->stats->incDequeued();
    }
}