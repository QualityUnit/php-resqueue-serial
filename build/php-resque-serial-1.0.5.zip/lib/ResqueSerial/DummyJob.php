<?php


namespace ResqueSerial;


class DummyJob {

    public function perform() {

    }
}