<?php


namespace Resque;


/**
 * Parent exception for all Resque specific exceptions.
 */
class Exception extends \Exception {
}