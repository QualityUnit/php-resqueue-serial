<?php


namespace Resque\Job\Reservations;


use Resque\Api\ResqueException;

class JobUnavailableException extends ResqueException {
}