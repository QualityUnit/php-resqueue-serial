<?php


namespace Resque\Api;


class DeferredException extends ResqueException {

}