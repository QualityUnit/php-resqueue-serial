<?php

namespace Resque;

/**
 * Redis related exceptions
 */
class RedisError extends \Error {
}